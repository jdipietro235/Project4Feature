Justin DiPietro
Computer Vision - Feature Matching

In the current state, this code will not display any plots. 
	This can be changed by uncommenting the plt.show() line in showCorrespondence.py

Code can also be found: https://github.com/jdipietro235/Project4Feature

Could not get the built-in display code working so a borrowed from here: https://stackoverflow.com/questions/17543359/drawing-lines-between-two-plots-in-matplotlib

Best of luck